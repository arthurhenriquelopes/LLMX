"""Llmx - agente assistente linux nativo para mx linux"""

__version__ = "0.1.0"
__author__ = "Arthur"
